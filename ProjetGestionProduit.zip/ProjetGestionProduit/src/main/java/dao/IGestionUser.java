package dao;

public interface IGestionUser {
	public	String verification(User u);
	public void registration(User u);
}
